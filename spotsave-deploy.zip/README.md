# SpotSave Project

## Встановлення Less

Для компіляції Less файлів в CSS потрібно встановити Node.js та npm.

### Встановлення Node.js

**Варіант 1: Через офіційний сайт (рекомендовано)**
1. Перейдіть на https://nodejs.org/
2. Завантажте LTS версію для macOS
3. Встановіть завантажений пакет

**Варіант 2: Через Homebrew**
```bash
# Спочатку встановіть Homebrew (якщо не встановлений)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Потім встановіть Node.js
brew install node
```

### Встановлення залежностей

Після встановлення Node.js виконайте:

```bash
npm install
```

### Використання

**Одноразова компіляція Less в CSS:**
```bash
npm run build:css
```

**Компіляція з source maps (для відлагодки):**
```bash
npm run build:css:sourcemap
```

**Автоматична компіляція при зміні файлів (watch mode):**
```bash
npm run watch:css
```

**Автоматична компіляція з source maps (рекомендовано для розробки):**
```bash
npm run watch:css:sourcemap
# або короткий варіант:
npm run dev
```

> 💡 **Важливо:** Після запуску `watch:css` або `dev`, процес буде працювати у фоновому режимі і автоматично компілювати `css/style.less` в `css/style.css` щоразу, коли ви зберігаєте зміни у файлі Less. Натисніть `Ctrl+C` для зупинки.

## Структура проєкту

- `css/style.less` - вихідний Less файл
- `css/style.css` - скомпільований CSS файл (генерується автоматично)
- `css/style.css.map` - source map файл (для відлагодки)

